<!DOCTYPE html>
<!-- GRC index.html v1.6.0 2026-08-23 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Meridian GRC</title>
<style>
/* ==SECTION:tokens== */
:root{
  --g-banner:#b01e24; --g-banner-dk:#8f171c; --g-rail:#e8e8e8; --g-rail-dk:#dcdcdc;
  --g-bg:#ffffff; --g-page:#f7f7f7; --g-card:#ffffff; --g-ink:#1f2430; --g-muted:#6a7280;
  --g-line:#d9dde3; --g-line-soft:#e9ecef; --g-accent:#2e6ea6;
  --g-ok:#15803d; --g-warn:#d97706; --g-bad:#991b1b; --g-info:#2e6ea6;
  --g-ok-bg:#e8f4ec; --g-warn-bg:#fbf0df; --g-bad-bg:#f7e8e8; --g-info-bg:#e8eff7;
  --g-r:6px; --g-shadow:0 1px 2px rgba(31,36,48,.06),0 4px 14px -8px rgba(31,36,48,.18);
}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;background:var(--g-page);color:var(--g-ink);
  font:14px/1.5 "Segoe UI",system-ui,-apple-system,Arial,sans-serif}
button,input,select{font:inherit;color:inherit}
a{color:var(--g-accent)}
/* ==SECTION:banner== */
#g-banner{background:var(--g-banner);color:#fff;display:flex;align-items:center;
  gap:16px;padding:0 16px;height:46px}
.g-brand{display:flex;align-items:center;gap:10px;font-size:16px;font-weight:600;
  letter-spacing:.2px;white-space:nowrap}
.g-brand svg{display:block}
#g-banner .sp{flex:1}
#g-search{width:280px;max-width:32vw;border:1px solid rgba(255,255,255,.45);
  background:rgba(255,255,255,.14);color:#fff;border-radius:4px;padding:5px 10px;outline:none}
#g-search::placeholder{color:rgba(255,255,255,.75)}
#g-search:focus{background:#fff;color:var(--g-ink)}
#g-release{font-size:12px;font-weight:600;background:rgba(255,255,255,.18);
  border:1px solid rgba(255,255,255,.4);border-radius:999px;padding:3px 10px;white-space:nowrap}
.g-roleWrap{display:flex;align-items:center;gap:6px;font-size:12px;color:rgba(255,255,255,.85)}
#g-role{background:var(--g-banner-dk);color:#fff;border:1px solid rgba(255,255,255,.35);
  border-radius:4px;padding:4px 6px;font-size:12px;max-width:200px}
#g-preflight-btn{background:transparent;color:#fff;border:1px solid rgba(255,255,255,.5);
  border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px}
#g-preflight-btn:hover{background:rgba(255,255,255,.15)}
#g-preflight-btn.err{background:#fff;color:var(--g-bad);font-weight:700}
/* ==SECTION:tabs== */
#g-tabs{background:var(--g-banner);display:flex;gap:2px;padding:0 12px;height:38px;align-items:flex-end}
#g-tabs button{border:none;background:transparent;color:rgba(255,255,255,.92);padding:9px 18px 10px;
  cursor:pointer;font-size:13.5px;font-weight:600;border-radius:6px 6px 0 0;letter-spacing:.2px}
#g-tabs button:hover{background:rgba(255,255,255,.14)}
#g-tabs button.on{background:var(--g-page);color:var(--g-ink)}
/* ==SECTION:trace== */
#g-trace{display:flex;align-items:center;gap:7px;flex-wrap:wrap;
  background:#fdf9f0;border-bottom:1px solid #ecdfc3;padding:5px 18px;font-size:12px}
#g-trace .tr-lbl{color:#8a7a55;font-size:11px;letter-spacing:.4px;text-transform:uppercase;font-weight:700}
#g-trace .tr-name{font-weight:650;color:var(--g-ink)}
.tr-chip{border:1.5px solid var(--g-banner);background:var(--g-banner);color:#fff;
  border-radius:5px;padding:1px 7px;font-size:11px;font-weight:700;cursor:pointer}
.tr-chip.uses{background:#fff;color:var(--g-ink);border-color:#8b93a0}
.tr-chip.feeds{background:#fff;color:var(--g-muted);border-color:#c3c9d1;border-style:dashed}
.tr-chip.future{border-style:dashed}
.tr-chip.primary.future{background:#fff;color:var(--g-banner)}
.tr-chip:hover{filter:brightness(.92)}
.tr-chip.pulse{animation:trpulse .9s ease}
@keyframes trpulse{0%{box-shadow:0 0 0 0 rgba(176,30,36,.55)}100%{box-shadow:0 0 0 12px rgba(176,30,36,0)}}
.tr-act{margin-left:auto;color:#8a5a10;font-weight:600;opacity:0;font-size:12px}
.tr-act.show{opacity:1;transition:opacity .2s}
/* ==SECTION:lens== */
.capbox.dim{opacity:.32;filter:grayscale(.9)}
.capbox.sel{border-color:var(--g-banner);border-width:2px;box-shadow:var(--g-shadow)}
.capbox.req{border-color:var(--g-warn);border-style:dashed;border-width:2px}
.capbox .selmark{position:absolute;top:6px;right:8px;font-size:11px;font-weight:800;color:var(--g-banner)}
.capbox .reqmark{position:absolute;top:6px;right:8px;font-size:10px;font-weight:800;color:var(--g-warn);letter-spacing:.4px}
/* ==SECTION:flowmap== */
.flowwrap{overflow-x:auto;border:1px solid var(--g-line);border-radius:8px;background:#fff;padding:6px}
.flowwrap svg text{font-family:"Segoe UI",system-ui,sans-serif}
/* ==SECTION:layout== */
#g-layout{display:flex;min-height:calc(100vh - 84px)}
#g-rail{width:236px;flex:none;background:var(--g-rail);border-right:1px solid #cfcfcf;
  display:flex;flex-direction:column;padding:14px 0 10px}
#g-rail h4{margin:2px 14px 6px;font-size:11px;letter-spacing:.9px;text-transform:uppercase;
  color:#5a6068;font-weight:700}
#g-rail .itm{display:block;width:100%;text-align:left;border:none;background:transparent;
  padding:8px 14px 8px 17px;cursor:pointer;color:#2a2f38;font-size:13.5px;border-left:3px solid transparent}
#g-rail .itm:hover{background:var(--g-rail-dk)}
#g-rail .itm.on{background:#fff;border-left-color:var(--g-banner);font-weight:600}
#g-rail .sep{flex:1}
#g-rail .persist{border-bottom:1px solid #c9c9c9;padding-bottom:8px;margin-bottom:10px}
#outlet{flex:1;min-width:0;padding:18px 22px 60px;max-width:1500px}
/* ==SECTION:components== */
.g-h1{font-size:20px;font-weight:650;margin:0 0 4px}
.g-h2{font-size:15px;font-weight:650;margin:0 0 8px}
.g-muted{color:var(--g-muted)}
.g-mono{font-family:Consolas,Menlo,monospace;font-size:12.5px}
.g-page-head{display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.g-page-head .sp{flex:1}
.g-card{background:var(--g-card);border:1px solid var(--g-line);border-radius:var(--g-r);
  box-shadow:var(--g-shadow);padding:14px 16px;margin-bottom:14px}
.g-card>.g-h2:first-child{margin-top:0}
.g-grid{display:grid;gap:14px}
.g-split{display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start}
@media(max-width:1100px){.g-split{grid-template-columns:1fr}}
.g-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.g-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:14px}
.g-kpi{background:var(--g-card);border:1px solid var(--g-line);border-radius:var(--g-r);
  box-shadow:var(--g-shadow);padding:10px 14px}
.g-kpi .v{font-size:23px;font-weight:650;font-variant-numeric:tabular-nums;line-height:1.15}
.g-kpi .l{font-size:11.5px;letter-spacing:.4px;text-transform:uppercase;color:var(--g-muted);font-weight:600}
.g-kpi .s{font-size:12px;color:var(--g-muted)}
.g-kpi.ok .v{color:var(--g-ok)} .g-kpi.warn .v{color:var(--g-warn)}
.g-kpi.bad .v{color:var(--g-bad)} .g-kpi.info .v{color:var(--g-info)}
.g-badge{display:inline-block;font-size:11px;font-weight:700;letter-spacing:.3px;
  padding:2px 8px;border-radius:999px;text-transform:uppercase;white-space:nowrap;
  background:#eef0f3;color:#3d4451;border:1px solid transparent}
.g-badge--ok{background:var(--g-ok-bg);color:var(--g-ok)}
.g-badge--warn{background:var(--g-warn-bg);color:#92580a}
.g-badge--bad{background:var(--g-bad-bg);color:var(--g-bad)}
.g-badge--info{background:var(--g-info-bg);color:#215582}
.g-pill{display:inline-block;font-size:12px;background:#f0f2f5;border:1px solid var(--g-line);
  border-radius:999px;padding:2px 10px;margin:2px 4px 2px 0;white-space:nowrap}
.g-pill.x{background:var(--g-bad-bg);border-color:#e5c9c9;color:var(--g-bad);text-decoration:line-through}
.g-btn{background:#fff;border:1px solid #b9bfc7;border-radius:4px;padding:6px 14px;cursor:pointer;font-size:13px}
.g-btn:hover{background:#f2f4f6}
.g-btn--primary{background:var(--g-banner);border-color:var(--g-banner);color:#fff;font-weight:600}
.g-btn--primary:hover{background:var(--g-banner-dk)}
.g-btn:disabled{opacity:.45;cursor:default}
.g-btn.sm{padding:3px 10px;font-size:12px}
.g-input,.g-select{border:1px solid #b9bfc7;border-radius:4px;padding:6px 9px;background:#fff;font-size:13px}
.g-input:focus,.g-select:focus{outline:2px solid #9db8d2;outline-offset:0}
.g-toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
.g-toolbar .lbl{font-size:12px;color:var(--g-muted)}
.g-empty{padding:26px;text-align:center;color:var(--g-muted);background:#fafbfc;
  border:1px dashed var(--g-line);border-radius:var(--g-r)}
.g-label{font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:var(--g-muted);font-weight:700}
/* ==SECTION:tables== */
.g-tablewrap{overflow-x:auto;background:var(--g-card);border:1px solid var(--g-line);
  border-radius:var(--g-r);box-shadow:var(--g-shadow);margin-bottom:14px}
table.g-table{border-collapse:collapse;width:100%;font-size:13px}
.g-table th{position:sticky;top:0;background:#f2f4f6;text-align:left;font-size:11px;
  letter-spacing:.5px;text-transform:uppercase;color:#4c5560;padding:8px 12px;
  border-bottom:1px solid var(--g-line);white-space:nowrap;cursor:default}
.g-table th.sort{cursor:pointer}
.g-table th.sort:hover{color:var(--g-ink)}
.g-table td{padding:7px 12px;border-bottom:1px solid var(--g-line-soft);vertical-align:top}
.g-table tr:last-child td{border-bottom:none}
.g-table tr.click{cursor:pointer}
.g-table tr.click:hover td{background:#f4f7fa}
.g-table td.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.g-pager{display:flex;gap:8px;align-items:center;justify-content:flex-end;padding:8px 12px;
  font-size:12px;color:var(--g-muted)}
/* ==SECTION:kv-tabs-drawer== */
.g-kv{display:grid;grid-template-columns:170px 1fr;gap:4px 14px;font-size:13px}
.g-kv dt{color:var(--g-muted)} .g-kv dd{margin:0;min-width:0}
.g-tabs{display:flex;gap:2px;border-bottom:2px solid var(--g-line);margin:6px 0 14px;flex-wrap:wrap}
.g-tabs button{border:none;background:transparent;padding:7px 14px;cursor:pointer;font-size:13px;
  font-weight:600;color:var(--g-muted);border-bottom:2px solid transparent;margin-bottom:-2px}
.g-tabs button:hover{color:var(--g-ink)}
.g-tabs button.on{color:var(--g-banner);border-bottom-color:var(--g-banner)}
.g-drawer-bg{position:fixed;inset:0;background:rgba(20,24,32,.42);z-index:60}
.g-drawer{position:fixed;top:0;right:0;bottom:0;width:min(680px,92vw);background:#fff;
  z-index:61;box-shadow:-8px 0 30px rgba(0,0,0,.25);display:flex;flex-direction:column}
.g-drawer .hd{display:flex;align-items:center;gap:10px;padding:12px 18px;
  border-bottom:1px solid var(--g-line);background:#f7f8fa}
.g-drawer .bd{padding:16px 18px;overflow:auto;flex:1}
.g-toast{position:fixed;right:18px;bottom:18px;z-index:80;background:#20262f;color:#fff;
  padding:10px 16px;border-radius:6px;font-size:13px;box-shadow:0 6px 24px rgba(0,0,0,.35);
  max-width:420px}
/* ==SECTION:special== */
.g-chat{background:#f6f8fa;border:1px solid var(--g-line);border-radius:var(--g-r);padding:10px;max-height:330px;overflow:auto}
.g-chat .m{max-width:88%;margin:6px 0;padding:7px 11px;border-radius:10px;font-size:13px;line-height:1.45}
.g-chat .m.assistant{background:#fff;border:1px solid var(--g-line)}
.g-chat .m.user{background:var(--g-info-bg);margin-left:auto}
.g-chat .who{font-size:10.5px;letter-spacing:.5px;text-transform:uppercase;color:var(--g-muted);margin-bottom:2px}
.g-prog{height:8px;border-radius:99px;background:#e7eaee;overflow:hidden}
.g-prog i{display:block;height:100%;background:var(--g-accent)}
.g-zone{border-left:4px solid var(--g-line);padding-left:12px;margin:16px 0}
.g-zone.likely{border-color:var(--g-ok)} .g-zone.middle{border-color:var(--g-warn)}
.g-zone.unlikely{border-color:#aab1ba}
.g-score{display:inline-flex;align-items:center;gap:6px;font-variant-numeric:tabular-nums;font-weight:650}
.g-score i{display:inline-block;width:44px;height:7px;border-radius:99px;background:#e7eaee;overflow:hidden}
.g-score i b{display:block;height:100%;background:var(--g-accent)}
.map-phase{border:1px solid var(--g-line);border-radius:var(--g-r);margin-bottom:10px;background:#fff}
.map-phase .ph{padding:7px 12px;background:#f2f4f6;font-weight:650;font-size:12.5px;border-bottom:1px solid var(--g-line);
  text-transform:uppercase;letter-spacing:.4px;color:#4c5560}
.map-step{display:flex;gap:10px;padding:7px 12px;border-bottom:1px solid var(--g-line-soft);align-items:flex-start}
.map-step:last-child{border-bottom:none}
.map-step .n{flex:none;width:22px;height:22px;border-radius:50%;background:#eef0f3;font-size:11.5px;
  font-weight:700;display:flex;align-items:center;justify-content:center;color:#4c5560}
.map-step.decision .n{background:var(--g-warn-bg);color:#92580a}
.map-step.h-in .n,.map-step.h-out .n{background:var(--g-info-bg);color:#215582}
.provsrc{font-size:11px;color:var(--g-muted);background:#f0f2f5;border-radius:4px;padding:1px 6px;margin-left:6px;white-space:nowrap}
.ans-yes{color:var(--g-ok);font-weight:700} .ans-no{color:var(--g-ink);font-weight:700}
#preflight .g-kv{grid-template-columns:220px 1fr}
.pf-err{color:var(--g-bad);font-family:Consolas,monospace;font-size:12px;white-space:pre-wrap}
.capbox{border:1.5px solid var(--g-line);border-radius:8px;padding:10px 12px;background:#fff;cursor:pointer;position:relative}
.capbox:hover{border-color:var(--g-accent)}
.capbox.live{border-color:var(--g-banner);box-shadow:var(--g-shadow)}
.capbox .cn{font-size:11px;font-weight:700;color:var(--g-muted);padding-right:66px}
.capbox .ct{font-weight:650;font-size:13px;line-height:1.3}
.capbox .cs{font-size:11px;margin-top:4px}
.g-badge--brand{background:#f6e4e5;color:var(--g-banner)}
/* ==SECTION:feedback== */
#g-fb-pill{position:fixed;left:14px;bottom:14px;z-index:55;background:#fff;
  border:1.5px solid var(--g-banner);color:var(--g-banner);border-radius:999px;
  padding:8px 16px;font-size:12.5px;font-weight:700;cursor:pointer;box-shadow:var(--g-shadow)}
#g-fb-pill:hover{background:var(--g-banner);color:#fff}
/* ==SECTION:worklist== */
#g-cart-pill{position:fixed;right:14px;bottom:14px;z-index:55;background:#fff;
  border:1.5px solid var(--g-accent);color:var(--g-accent);border-radius:999px;
  padding:8px 16px;font-size:12.5px;font-weight:700;cursor:pointer;box-shadow:var(--g-shadow)}
#g-cart-pill:hover{background:var(--g-accent);color:#fff}
#g-cart-pill .n{background:var(--g-accent);color:#fff;border-radius:999px;padding:0 7px;margin-left:6px}
#g-cart-pill:hover .n{background:#fff;color:var(--g-accent)}
.g-btn.cart-in{background:var(--g-info-bg);border-color:var(--g-accent);color:var(--g-accent);font-weight:600}
#g-cartbar{position:fixed;left:50%;bottom:64px;transform:translateX(-50%);z-index:70;
  background:#1f2430;color:#fff;border-radius:10px;padding:10px 16px;
  box-shadow:0 8px 28px rgba(0,0,0,.4);display:flex;gap:9px;align-items:center;
  max-width:min(860px,92vw);font-size:13px}
#g-cartbar .t{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#g-cartbar .donechip{background:var(--g-ok);color:#fff;border-radius:999px;padding:1px 9px;
  font-size:10.5px;font-weight:800;letter-spacing:.4px;white-space:nowrap}
#g-cartbar button{border:1px solid rgba(255,255,255,.45);background:transparent;color:#fff;
  border-radius:5px;padding:4px 11px;cursor:pointer;font-size:12.5px;white-space:nowrap}
#g-cartbar button:hover{background:rgba(255,255,255,.15)}
#g-cartbar button.p{background:var(--g-accent);border-color:var(--g-accent);font-weight:600}
.fb-ctx{background:#f2f4f6;border:1px solid var(--g-line);border-radius:6px;
  padding:8px 12px;font-size:12.5px;margin-bottom:12px}
.fb-ctx .g-mono{font-size:12px}
.fb-item{border:1px solid var(--g-line);border-radius:6px;padding:8px 12px;margin:8px 0;background:#fff;font-size:12.5px}
.flowarrow{align-self:center;justify-self:center;width:0;height:0;
  border-top:6px solid transparent;border-bottom:6px solid transparent;border-left:8px solid #b9bfc7}
.caret{display:inline-block;width:0;height:0;border-top:5px solid transparent;
  border-bottom:5px solid transparent;border-left:7px solid #6a7280;margin-right:8px;
  cursor:pointer;transition:transform .12s;vertical-align:middle}
.caret.open{transform:rotate(90deg)}
.tree-ind1 td:first-child{padding-left:34px}
.tree-ind2 td:first-child{padding-left:58px}
tr.tree-parent{background:#f7f8fa}
tr.tree-parent td{font-weight:600}
.skel-strip{display:flex;gap:10px;margin-top:10px}
.skel-strip i{display:block;height:64px;flex:1;background:#f0f2f5;border:1px dashed var(--g-line);border-radius:6px}
.gal-item{border:1px solid var(--g-line);border-radius:8px;background:#fff;padding:12px 14px;display:flex;flex-direction:column;gap:6px}
.gal-item .t{font-weight:650}
.gal-item .w{font-size:12.5px;color:var(--g-muted);flex:1}
.vote button{border:1px solid #b9bfc7;background:#fff;border-radius:4px;padding:2px 9px;font-size:11.5px;cursor:pointer}
.vote button.on{background:var(--g-ink);color:#fff;border-color:var(--g-ink)}
:focus-visible{outline:2px solid var(--g-accent);outline-offset:1px}
@media print{#g-banner,#g-tabs,#g-rail,#g-fb-pill,#g-cart-pill,#g-cartbar{display:none}#outlet{padding:0}}
</style>
</head>
<body>
<header id="g-banner">
  <div class="g-brand">
    <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><rect x="1" y="1" width="20" height="20" rx="4" fill="#fff"/><rect x="4.5" y="4.5" width="4" height="4" rx="1" fill="#b01e24"/><rect x="9.5" y="4.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="14.5" y="4.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="4.5" y="9.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="9.5" y="9.5" width="4" height="4" rx="1" fill="#b01e24"/><rect x="14.5" y="9.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="4.5" y="14.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="9.5" y="14.5" width="4" height="4" rx="1" fill="#e3a6a8"/><rect x="14.5" y="14.5" width="4" height="4" rx="1" fill="#b01e24"/></svg>
    Meridian GRC
  </div>
  <span class="sp"></span>
  <input id="g-search" type="search" placeholder="Search RAUs, risk events, MCRs... (Enter)">
  <span id="g-release" title="Release shown to reviewers">R?</span>
  <span class="g-roleWrap">View as <select id="g-role"></select></span>
  <button id="g-preflight-btn" title="Diagnostics">Preflight</button>
</header>
<nav id="g-tabs" aria-label="Functions"></nav>
<div id="g-trace" hidden></div>
<div id="g-layout">
  <aside id="g-rail" aria-label="Section navigation">
    <div class="persist" id="g-rail-persist"><h4>Always available</h4></div>
    <h4 id="g-rail-title"></h4>
    <div id="g-rail-context"></div>
    <div class="sep"></div>
  </aside>
  <main id="outlet"></main>
</div>
<div id="preflight" hidden></div>
<!-- Kernel first, then data (one line per data file), then modules (one line
     per module). To swap in real data: replace files in data/ keeping the
     same filenames - no changes needed here. -->
<script src="kernel/core.js"></script>
<script src="kernel/engine.js"></script>
<script src="kernel/ui.js"></script>
<script src="kernel/charts.js"></script>
<script src="data/release.js"></script>
<script src="data/orgnodes.js"></script>
<script src="data/services.js"></script>
<script src="data/raus.js"></script>
<script src="data/riskevents.js"></script>
<script src="data/mcrs.js"></script>
<script src="data/register.js"></script>
<script src="data/requests.js"></script>
<script src="data/metaquestions.js"></script>
<script src="data/rubric.js"></script>
<script src="data/ratings.js"></script>
<script src="data/controls.js"></script>
<script src="data/controllinks.js"></script>
<script src="data/expectedcontrols.js"></script>
<script src="data/affirmations.js"></script>
<script src="data/challenges.js"></script>
<script src="modules/home.js"></script>
<script src="modules/gallery.js"></script>
<script src="modules/rau.js"></script>
<script src="modules/rau-profile.js"></script>
<script src="modules/intake.js"></script>
<script src="modules/mapbuilder.js"></script>
<script src="modules/riskid.js"></script>
<script src="modules/inherent.js"></script>
<script src="modules/controls.js"></script>
<script src="modules/rcsa.js"></script>
<script src="modules/skeletons.js"></script>
<script src="modules/libraries.js"></script>
<script src="modules/mywork.js"></script>
<script src="modules/demo.js"></script>
<script>window.addEventListener("load", function(){ GRC.boot(); });</script>
</body>
</html>
